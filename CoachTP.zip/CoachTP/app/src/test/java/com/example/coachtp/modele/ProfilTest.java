package com.example.coachtp.modele;

import static org.junit.Assert.*;

import org.junit.Test;

public class ProfilTest {

    private Profil profil = new Profil(67,165,35,0);

    private float img = (float)32.2;
    private String message = "trop elevé";
    @Test
    public void getImg() {
        assertEquals(img, profil.getImg(),(float)0.1);
    }

    @Test
    public void getMsg() {assertEquals(message,profil.getMsg());
    }
}